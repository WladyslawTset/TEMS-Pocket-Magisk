#!/system/bin/sh

input tap 600 150
sleep 1
input tap 400 2000
sleep 1
input tap 900 2142
sleep 1

exit 0
